/*
 * Copyright © 2020, 2021, 2022, 2023, 2024, 2025, 2026 Peter Doornbosch
 *
 * This file is part of Agent15, an implementation of TLS 1.3 in Java.
 *
 * Agent15 is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your option)
 * any later version.
 *
 * Agent15 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for
 * more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package tech.kwik.agent15.engine.impl;

import tech.kwik.agent15.TlsConstants;
import tech.kwik.agent15.handshake.HandshakeMessage;

import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

// https://tools.ietf.org/html/rfc8446#section-4.4.1
// "Many of the cryptographic computations in TLS make use of a transcript hash. This value is computed by hashing the
//  concatenation of each included handshake message, including the handshake message header carrying the handshake
//  message type and length fields, but not including record layer headers."
public class TranscriptHash {

    enum ExtendedHandshakeType {
        client_hello(1),
        server_hello(2),
        new_session_ticket(4),
        end_of_early_data(5),
        hello_retry_request(6),
        encrypted_extensions(8),
        certificate(11),
        certificate_request(13),
        certificate_verify(15),
        finished(20),
        key_update(24),
        server_certificate(244),
        server_certificate_verify(245),
        server_finished(246),
        client_certificate(247),
        client_certificate_verify(248),
        client_finished(249),
        message_hash(254),
        ;

        public final byte value;

        ExtendedHandshakeType(int value) {
            this.value = (byte) value;
        }
    }

    // https://tools.ietf.org/html/rfc8446#section-4.4.1
    // "For concreteness, the transcript hash is always taken from the
    //   following sequence of handshake messages, starting at the first
    //   ClientHello and including only those messages that were sent:
    //   ClientHello, HelloRetryRequest, ClientHello, ServerHello,
    //   EncryptedExtensions, server CertificateRequest, server Certificate,
    //   server CertificateVerify, server Finished, EndOfEarlyData, client
    //   Certificate, client CertificateVerify, client Finished."
    private static ExtendedHandshakeType[] hashedMessages = {
            // The first two are only present when a hello retry request was received; in that case, the client_hello
            // entry holds the second client hello.
            ExtendedHandshakeType.message_hash,
            ExtendedHandshakeType.hello_retry_request,
            ExtendedHandshakeType.client_hello,
            ExtendedHandshakeType.server_hello,
            ExtendedHandshakeType.encrypted_extensions,
            ExtendedHandshakeType.certificate_request,
            ExtendedHandshakeType.server_certificate,
            ExtendedHandshakeType.server_certificate_verify,
            ExtendedHandshakeType.server_finished,
            ExtendedHandshakeType.client_certificate,
            ExtendedHandshakeType.client_certificate_verify,
            ExtendedHandshakeType.client_finished
    };

    private final MessageDigest hashFunction;

    private Map<ExtendedHandshakeType, byte[]> msgData = new ConcurrentHashMap<>();
    private Map<ExtendedHandshakeType, byte[]> hashes = new ConcurrentHashMap<>();


    public TranscriptHash(int hashLength) {
        // https://tools.ietf.org/html/rfc8446#section-7.1
        // "The Hash function used by Transcript-Hash and HKDF is the cipher suite hash algorithm."
        String hashAlgorithm = "SHA-" + (hashLength * 8);
        try {
            hashFunction = MessageDigest.getInstance(hashAlgorithm);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Missing " + hashAlgorithm + " support");
        }
    }

    /**
     * Return the transcript hash for the messages in the handshake up to and including the indicated message type.
     * @param msgType
     * @return
     */
    public byte[] getHash(TlsConstants.HandshakeType msgType) {
        return getHash(convert(msgType));
    }

    /**
     * Return the transcript hash for the messages in the handshake up to and including the indicated client message type.
     * For example, when the <code>msgType</code> parameter has value <code>certificate</code>, the transcript hash for
     * the concatenation of handshake messages up to (and including) the client certificate message is returned.
     * @param msgType
     * @return
     */
    public byte[] getClientHash(TlsConstants.HandshakeType msgType) {
        return getHash(convert(msgType, true));
    }

    /**
     * Return the transcript hash for the messages in the handshake up to and including the indicated server message type.
     * For example, when the <code>msgType</code> parameter has value <code>certificate</code>, the transcript hash for
     * the concatenation of handshake messages up to (and including) the server certificate message is returned.
     * @param msgType
     * @return
     */
    public byte[] getServerHash(TlsConstants.HandshakeType msgType) {
        return getHash(convert(msgType, false));
    }

    /**
     * Record a handshake message for computing the transcript hash. The type of the message determines its position
     * in the transcript hash computation.
     * @param msg
     */
    public void record(HandshakeMessage msg) {
        // Note that convert() rejects the message types that occur both as client and as server message; for those,
        // recordClient or recordServer must be used.
        msgData.put(convert(msg.getType()), msg.getBytes());
    }

    /**
     * Record a client handshake message for computing the transcript hash. This method is needed because the
     * <code>TlsConstants.HandshakeType</code> type does not differentiate between client and server variants, whilst
     * these variants have a different position in the transcript hash computation.
     * Note that the term "client" here refers to the message type, not whether it is sent or received by a client.
     * For example, a client certificate message is sent by the client and received by the server; both need to use
     * this method to record the message.
     * @param msg
     */
    public void recordClient(HandshakeMessage msg) {
        msgData.put(convert(msg.getType(), true), msg.getBytes());
    }

    /**
     * Record a server handshake message for computing the transcript hash. This method is needed because the
     * <code>TlsConstants.HandshakeType</code> type does not differentiate between client and server variants, whilst
     * these variants have a different position in the transcript hash computation.
     * Note that the term "server" here refers to the message type, not whether it is sent or received by a server.
     * For example, a server certificate message is sent by the server and received by the client; both need to use
     * this method to record the message.
     * @param msg
     */
    public void recordServer(HandshakeMessage msg) {
        msgData.put(convert(msg.getType(), false), msg.getBytes());
    }

    /**
     * Record the client hello / hello retry request exchange that precedes the second client hello.
     * https://datatracker.ietf.org/doc/html/rfc8446#section-4.4.1
     * "As an exception to this general rule, when the server responds to a ClientHello with a HelloRetryRequest, the
     *  value of ClientHello1 is replaced with a special synthetic handshake message of handshake type "message_hash"
     *  containing Hash(ClientHello1). I.e.,
     *    Transcript-Hash(ClientHello1, HelloRetryRequest, ... Mn) =
     *        Hash(message_hash || 00 00 Hash.length || Hash(ClientHello1) || HelloRetryRequest || ... || Mn)"
     * where the first four bytes are the handshake message header: the message_hash type followed by the message
     * length as a uint24.
     * After calling this method, the second client hello should be recorded with the ordinary <code>record</code>
     * method; it takes the position of the first one, which is represented by the synthetic message from here on.
     *
     * @param clientHello1        the first client hello, the one that triggered the hello retry request
     * @param helloRetryRequest   the hello retry request
     */
    public void recordHelloRetryRequest(HandshakeMessage clientHello1, HandshakeMessage helloRetryRequest) {
        hashFunction.reset();
        byte[] clientHello1Hash = hashFunction.digest(clientHello1.getBytes());

        ByteBuffer syntheticMessage = ByteBuffer.allocate(4 + clientHello1Hash.length);
        syntheticMessage.put(TlsConstants.HandshakeType.message_hash.value);
        syntheticMessage.put((byte) 0x00);
        syntheticMessage.put((byte) 0x00);
        syntheticMessage.put((byte) clientHello1Hash.length);
        syntheticMessage.put(clientHello1Hash);

        msgData.put(ExtendedHandshakeType.message_hash, syntheticMessage.array());
        msgData.put(ExtendedHandshakeType.hello_retry_request, helloRetryRequest.getBytes());
        // The first client hello is no longer part of the transcript as such; its place is taken by the synthetic
        // message, and the client_hello position is now reserved for the second client hello.
        msgData.remove(ExtendedHandshakeType.client_hello);
        // Messages are normally recorded in transcript order, so a hash that was computed before remains valid when a
        // later message is added. Recording a hello retry request is the exception: it inserts messages at the very
        // start of the transcript and replaces the client hello, so any hash computed up to now is invalidated.
        hashes.clear();
    }

    /**
     * Returns the part of the transcript that precedes the second client hello: the synthetic message that replaces
     * the first client hello, followed by the hello retry request. This is the prefix over which the binders in the
     * second client hello must be computed, see https://datatracker.ietf.org/doc/html/rfc8446#section-4.2.11.2.
     * @return  the prefix, or an empty array when no hello retry request was recorded.
     */
    public byte[] getHelloRetryRequestPrefix() {
        byte[] syntheticMessage = msgData.get(ExtendedHandshakeType.message_hash);
        byte[] helloRetryRequest = msgData.get(ExtendedHandshakeType.hello_retry_request);
        if (syntheticMessage == null || helloRetryRequest == null) {
            return new byte[0];
        }
        ByteBuffer prefix = ByteBuffer.allocate(syntheticMessage.length + helloRetryRequest.length);
        prefix.put(syntheticMessage);
        prefix.put(helloRetryRequest);
        return prefix.array();
    }

    private byte[] getHash(ExtendedHandshakeType type) {
        if (! hashes.containsKey(type)) {
            computeHash(type);
        }
        return hashes.get(type);
    }

   private void computeHash(ExtendedHandshakeType requestedType) {
        for (ExtendedHandshakeType type: hashedMessages) {
            if (msgData.containsKey(type)) {
                hashFunction.update(msgData.get(type));
            }
            if (type == requestedType) {
                break;
            }
        }
        hashes.put(requestedType, hashFunction.digest());
    }

    /**
     * Maps a handshake message type on its position in the transcript hash computation. Message types that occur both
     * as a client and as a server message cannot be mapped by this method, as these variants have a different position
     * in the transcript hash computation; use <code>convert(type, boolean)</code> for those.
     */
    static ExtendedHandshakeType convert(TlsConstants.HandshakeType type) {
        switch (type) {
            case client_hello:
                return ExtendedHandshakeType.client_hello;
            case server_hello:
                return ExtendedHandshakeType.server_hello;
            case new_session_ticket:
                return ExtendedHandshakeType.new_session_ticket;
            case end_of_early_data:
                return ExtendedHandshakeType.end_of_early_data;
            case encrypted_extensions:
                return ExtendedHandshakeType.encrypted_extensions;
            case certificate_request:
                return ExtendedHandshakeType.certificate_request;
            case key_update:
                return ExtendedHandshakeType.key_update;
            case certificate:
            case certificate_verify:
            case finished:
                throw new IllegalArgumentException("cannot convert ambiguous type " + type);
            default:
                throw new IllegalArgumentException("no transcript hash position defined for type " + type);
        }
    }

    /**
     * Maps a handshake message type on its position in the transcript hash computation, where the <code>client</code>
     * parameter indicates whether it concerns the client or the server variant of the message type.
     */
    static ExtendedHandshakeType convert(TlsConstants.HandshakeType type, boolean client) {
        switch (type) {
            case certificate:
                return client? ExtendedHandshakeType.client_certificate: ExtendedHandshakeType.server_certificate;
            case certificate_verify:
                return client? ExtendedHandshakeType.client_certificate_verify: ExtendedHandshakeType.server_certificate_verify;
            case finished:
                return client? ExtendedHandshakeType.client_finished: ExtendedHandshakeType.server_finished;
            default:
                return convert(type);
        }
    }
}
