/*
 * Copyright © 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026 Peter Doornbosch
 *
 * This file is part of Kwik, an implementation of the QUIC protocol in Java.
 *
 * Kwik is free software: you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your option)
 * any later version.
 *
 * Kwik is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for
 * more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package tech.kwik.core.frame;

import tech.kwik.core.generic.IntegerTooLargeException;
import tech.kwik.core.generic.InvalidIntegerEncodingException;
import tech.kwik.core.generic.VariableLengthInteger;
import tech.kwik.core.impl.TransportError;
import tech.kwik.core.impl.Version;
import tech.kwik.core.log.Logger;
import tech.kwik.core.packet.PacketMetaData;
import tech.kwik.core.packet.QuicPacket;
import tech.kwik.core.stream.StreamElement;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Objects;

import static tech.kwik.core.QuicConstants.TransportErrorCode.FRAME_ENCODING_ERROR;


public class StreamFrame extends QuicFrame implements StreamElement {

    private static final byte[] EMPTY_DATA = new byte[0];

    // Stream frames can be buffered in large numbers (in send, retransmit and receive buffers), so the fields are kept
    // to a minimum to reduce memory footprint. With a 12 byte object header (compressed class pointers) and objects
    // aligned to 8 bytes, the fields below result in an object size of 32 bytes.
    // The frame length is stored (and not computed on the fly) because it is used often when assembling packets;
    // as it never exceeds the max packet size (1500), a short suffices. The isFinal boolean could be stored in the MSB
    // of the frameLength, but that wouldn't make the object smaller because of padding (unless +UseCompactObjectHeaders).
    private int streamId;
    private long offset;
    private byte[] streamData;
    private short frameLength;
    private boolean isFinal;

    public StreamFrame() {
        streamData = EMPTY_DATA;
    }

    public StreamFrame(int streamId, byte[] applicationData, boolean fin) {
        this(Version.getDefault(), streamId, 0, applicationData, 0, applicationData.length, fin);
    }

    public StreamFrame(int streamId, long offset, byte[] applicationData, boolean fin) {
        this(Version.getDefault(), streamId, offset, applicationData, 0, applicationData.length, fin);
    }

    public StreamFrame(Version quicVersion, int streamId, long offset, byte[] applicationData, boolean fin) {
        this(quicVersion, streamId, offset, applicationData, 0, applicationData.length, fin);
    }

    public StreamFrame(int streamId, long offset, byte[] applicationData, int dataOffset, int dataLength, boolean fin) {
        this(Version.getDefault(), streamId, offset, applicationData, dataOffset, dataLength, fin);
    }

    public StreamFrame(Version quicVersion, int streamId, long streamOffset, byte[] applicationData, int dataOffset, int dataLength, boolean fin) {
        this.streamId = streamId;
        this.offset = streamOffset;
        this.streamData = new byte[dataLength];
        // This implementation copies the application data, which would not be necessary if the caller guarantees
        // it will not reuse the data buffer (or at least, the range that is used by this frame) and its content
        // will never change.
        ByteBuffer.wrap(streamData).put(applicationData, dataOffset, dataLength);

        isFinal = fin;

        frameLength = (short) (1  // frame type
                + VariableLengthInteger.bytesNeeded(streamId)
                + VariableLengthInteger.bytesNeeded(offset)
                + VariableLengthInteger.bytesNeeded(dataLength)
                + dataLength);
    }

    @Override
    public void serialize(ByteBuffer buffer) {
        if ((int) frameLength > buffer.remaining()) {
            throw new IllegalArgumentException();
        }

        byte baseType = (byte) 0x08;
        byte frameType = (byte) (baseType | 0x04 | 0x02 | 0x00);  // OFF-bit, LEN-bit, (no) FIN-bit
        if (isFinal) {
            frameType |= 0x01;
        }
        buffer.put(frameType);
        VariableLengthInteger.encode(streamId, buffer);
        VariableLengthInteger.encode(offset, buffer);
        VariableLengthInteger.encode(streamData.length, buffer);
        buffer.put(streamData);
    }

    @Override
    public int getFrameLength() {
        return frameLength;
    }

    public StreamFrame parse(ByteBuffer buffer, Logger log) throws InvalidIntegerEncodingException, TransportError, IntegerTooLargeException {
        int startPosition = buffer.position();

        int frameType = buffer.get();
        boolean withOffset = ((frameType & 0x04) == 0x04);
        boolean withLength = ((frameType & 0x02) == 0x02);
        isFinal = ((frameType & 0x01) == 0x01);

        streamId = parseVariableLengthIntegerLimitedToInt(buffer);  // Kwik does not support stream id's larger than max int.

        if (withOffset) {
            offset = VariableLengthInteger.parseLong(buffer);
        }
        int length;
        if (withLength) {
            length = VariableLengthInteger.parseInt(buffer);
            if (length > buffer.remaining()) {
                throw new TransportError(FRAME_ENCODING_ERROR, "Stream frame length exceeds remaining buffer length");
            }
        }
        else {
            length = buffer.limit() - buffer.position();
        }

        streamData = new byte[length];
        buffer.get(streamData);
        frameLength = (short) (buffer.position() - startPosition);

        log.decrypted("Stream data", streamData);

        return this;
    }

    @Override
    public String toString() {
        StreamType streamType = StreamType.values()[streamId & 0x03];
        return "StreamFrame[" + streamId + "(" + streamType.abbrev + ")" + "," + offset + "," + streamData.length + (isFinal? ",fin": "") + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StreamFrame)) return false;
        StreamFrame that = (StreamFrame) o;
        return streamId == that.streamId &&
                offset == that.offset &&
                streamData.length == that.streamData.length &&
                isFinal == that.isFinal &&
                Arrays.equals(streamData, that.streamData);
    }

    @Override
    public int hashCode() {
        return Objects.hash(streamId, offset, streamData.length);
    }

    @Override
    public int compareTo(StreamElement other) {
        if (this.offset != other.getOffset()) {
            return Long.compare(this.offset, other.getOffset());
        }
        else {
            return Long.compare(streamData.length, other.getLength());
        }
    }

    public int getStreamId() {
        return streamId;
    }

    public long getOffset() {
        return offset;
    }

    /**
     * Returns length of the data carried by this frame.
     * @return  data length
     */
    public int getLength() {
        return streamData.length;
    }

    public byte[] getStreamData() {
        return streamData;
    }

    @Override
    public long getUpToOffset() {
        return offset + streamData.length;
    }

    public boolean isFinal() {
        return isFinal;
    }

    static public int maxOverhead() {
        return 1  // frame type
        + 4 // stream id
        + 4 // offset
        + 4 // length
        ;
    }

    @Override
    public void accept(FrameProcessor frameProcessor, QuicPacket packet, PacketMetaData metaData) {
        frameProcessor.process(this, packet, metaData);
    }
}
